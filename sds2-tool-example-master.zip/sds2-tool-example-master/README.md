### Tool example
This SDS/2 plugin is an example of a Tool in SDS/2.